-- Add company_name to profiles if it doesn't exist
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' 
    AND column_name = 'company_name'
  ) THEN
    ALTER TABLE public.profiles ADD COLUMN company_name text;
  END IF;
END $$;

-- Add producer_number to profiles if it doesn't exist
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' 
    AND column_name = 'producer_number'
  ) THEN
    ALTER TABLE public.profiles ADD COLUMN producer_number text;
  END IF;
END $$;

-- Create sequence for producer numbers
CREATE SEQUENCE IF NOT EXISTS producer_number_seq START 1;

-- Function to generate producer number
CREATE OR REPLACE FUNCTION generate_producer_number()
RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
  next_number integer;
  generated_number text;
BEGIN
  LOOP
    -- Get next number from sequence
    SELECT nextval('producer_number_seq') INTO next_number;
    -- Format as mbfpr-XXX where XXX is padded with zeros
    generated_number := 'mbfpr-' || LPAD(next_number::text, 3, '0');
    
    -- Check if this number already exists
    IF NOT EXISTS (
      SELECT 1 FROM profiles 
      WHERE producer_number = generated_number
    ) THEN
      RETURN generated_number;
    END IF;
  END LOOP;
END;
$$;

-- Set initial producer number for Knockriobeats
UPDATE public.profiles 
SET producer_number = 'mbfpr-001',
    company_name = 'MyBeatFi - iLi Media Group'
WHERE email = 'knockriobeats@gmail.com'
AND (producer_number IS NULL OR company_name IS NULL);

-- Trigger to auto-assign producer number
CREATE OR REPLACE FUNCTION assign_producer_number()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.account_type = 'producer' AND NEW.producer_number IS NULL THEN
    NEW.producer_number = generate_producer_number();
  END IF;
  RETURN NEW;
END;
$$;

-- Drop trigger if it exists to avoid conflicts
DROP TRIGGER IF EXISTS assign_producer_number_trigger ON public.profiles;

-- Create trigger
CREATE TRIGGER assign_producer_number_trigger
BEFORE INSERT ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION assign_producer_number();